# FORGE-OS 5.5.3

The complete encounter tracker and character-sheet builder, with the original terminal aesthetic and 5.5.2 game rules. No patch overlays are needed for this archive.

## Start

Install Node.js 22.12 or newer. In this folder run:

```sh
npm ci
npm run dev
```

Open http://localhost:8080 and leave the server running. See SETUP.txt for clearance profiles, LAN access and remote shared-table setup.

Choose GUEST to build a new sheet, MECHANIC to edit a saved manifest, IMPERIAL INTELLIGENCE for a solo encounter, or LIVE DATA INTERCEPT for a shared table. The first shared-table seat is the host.

## New controls

- TARGET selects an incoming-damage component; ACTIONS opens its repair controls.
- Small ▾ buttons expose equipment and combat options by click or touch.
- SHEET ACTIONS manages the current unit; encounters with four or more sheets have a name/owner filter.
- DISPLAY remembers Compact/Roomy spacing and Terminal/Reduced effects. HELP explains the current screen.
- On small screens, WORKSPACE, LOADOUT and CONSOLE switch between panels.
- Common rolls and active defenses appear above skill-input setup.

The default local table uses an in-memory database and resets when the server stops. Configure a persistent PostgreSQL DATABASE_URL for persistence. The existing persistent seat-color migration is included.

## Development

UI sources are public/terminal-ui.css and public/terminal-ui.js. After editing, embed them into the terminal:

```sh
node devtools/embed-v553-ui.cjs public
```

The terminal embeds the UI so exported catalogue HTML retains its appearance. Shared tables still require this server.

Validation commands:

```sh
npm run typecheck
npm run build
node devtools/check-v553.cjs
node devtools/check-v553-workflows.cjs
```

Browser checks require Chromium. Set CHROMIUM_PATH to its executable; the default is /usr/bin/chromium. Run them against the development server, or set BASE_URL.

Both browser suites pass (44 checks), as do the production build, typecheck, 59 TypeScript unit tests and seven server ownership assertions. The inherited template tooling has 17 failures reproduced unchanged against the pristine base; see CHANGELOG-v5.5.3.md.
